# -*- coding: utf-8 -*-
"""LLM client for interacting with Google Gemini API."""

import os
import asyncio
from typing import Dict, List, Optional, Union, Any, Tuple
import json

import google.generativeai as genai
# Removed all specific type imports from types, relying on basic dicts and response object attributes
from google.generativeai.types import GenerateContentResponse # Keep this for response type hint
from google.api_core import exceptions as google_exceptions

from app.config import LLMSettings, config
from app.exceptions import TokenLimitExceeded
from app.logger import logger
from app.schema import (
    ROLE_VALUES,
    TOOL_CHOICE_TYPE,
    TOOL_CHOICE_VALUES,
    Message,
    ToolChoice,
)

# Mapping OpenAI roles to Gemini roles
ROLE_MAP = {
    "system": "user", # Treat system as user for history, handle separately if model supports it
    "user": "user",
    "assistant": "model",
    "tool": "function", # Gemini uses function role for tool *responses*
}

# Gemini models known to support function calling
FUNCTION_CALLING_MODELS = ["gemini-1.5-flash", "gemini-1.5-pro", "gemini-pro"]
# Gemini models known to support vision
VISION_MODELS = ["gemini-1.5-flash", "gemini-1.5-pro", "gemini-pro-vision"]

class LLM:
    _instances: Dict[str, "LLM"] = {}

    def __new__(
        cls,
        config_name: str = "default",
        llm_config: Optional[LLMSettings] = None,
    ):
        if config_name not in cls._instances:
            instance = super().__new__(cls)
            instance._initialized = False
            cls._instances[config_name] = instance
        return cls._instances[config_name]

    def __init__(
        self,
        config_name: str = "default",
        llm_config: Optional[LLMSettings] = None,
    ):
        if hasattr(self, "_initialized") and self._initialized:
            return

        logger.info(f"Initializing LLM with config: {config_name}")
        llm_config = llm_config or config.llm
        llm_config = llm_config.get(config_name, llm_config["default"])

        self.api_key = os.environ.get("GEMINI_API_KEY")
        if not self.api_key:
            # Check config as a fallback (less secure)
            self.api_key = getattr(llm_config, 'api_key', None)
            if not self.api_key:
                 raise ValueError("GEMINI_API_KEY environment variable not set, and no api_key found in config.")
            else:
                 logger.warning("Using API key from config file. Setting via environment variable GEMINI_API_KEY is recommended.")

        try:
            genai.configure(api_key=self.api_key)
        except Exception as e:
            logger.error(f"Failed to configure Gemini API: {e}")
            raise

        self.model_name = llm_config.model
        try:
            # Ensure model name format (e.g., some versions might need models/ prefix)
            model_ref = self.model_name if self.model_name.startswith("models/") else f"models/{self.model_name}"
            self.client = genai.GenerativeModel(model_ref)
            logger.info(f"Gemini client initialized with model: {model_ref}")
        except Exception as e:
            logger.error(f"Failed to initialize Gemini GenerativeModel ({model_ref}): {e}")
            raise

        self.max_output_tokens = llm_config.max_tokens
        self.temperature = llm_config.temperature
        self.top_p = getattr(llm_config, 'top_p', None)
        self.top_k = getattr(llm_config, 'top_k', None)

        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.max_input_tokens = getattr(llm_config, 'max_input_tokens', None)

        self._initialized = True
        logger.info(f"LLM initialization complete for config: {config_name}")

    async def count_tokens(self, content: Union[str, List[Union[str, dict]]]) -> int:
        """Calculate the number of tokens using the Gemini API (synchronous wrapper)."""
        try:
            # Prepare content for the synchronous count_tokens method
            if isinstance(content, str):
                formatted_content = [content]
            elif isinstance(content, list):
                # count_tokens expects list of strings or dicts with 'parts'
                # Ensure the format is roughly correct for counting
                formatted_content = content
            else:
                 formatted_content = [str(content)]

            loop = asyncio.get_running_loop()
            # Run the synchronous count_tokens in an executor
            response = await loop.run_in_executor(
                None, self.client.count_tokens, formatted_content
            )
            return response.total_tokens
        except Exception as e:
            # Log error and return 0 or estimate based on text length
            logger.error(f"Error counting tokens with Gemini API: {e}")
            # Simple estimation fallback (optional)
            # estimated_tokens = sum(len(str(item)) // 4 for item in formatted_content)
            # logger.warning(f"Falling back to estimated token count: {estimated_tokens}")
            # return estimated_tokens
            return 0

    def update_token_count(self, input_tokens: int, output_tokens: int = 0) -> None:
        """Update token counts (mainly for logging)."""
        self.total_input_tokens += input_tokens
        self.total_output_tokens += output_tokens
        logger.info(
            f"Gemini Token usage: Input={input_tokens}, Output={output_tokens}, "
            f"Cumulative Input={self.total_input_tokens}, Cumulative Output={self.total_output_tokens}, "
            f"Total={input_tokens + output_tokens}, Cumulative Total={self.total_input_tokens + self.total_output_tokens}"
        )

    def check_token_limit(self, input_tokens: int) -> bool:
        """Check if token limits are exceeded (client-side estimate)."""
        if self.max_input_tokens is not None:
            return (self.total_input_tokens + input_tokens) <= self.max_input_tokens
        return True # Rely on API errors if no client-side limit set

    def get_limit_error_message(self, input_tokens: int) -> str:
        """Generate error message for token limit exceeded (client-side estimate)."""
        if (
            self.max_input_tokens is not None
            and (self.total_input_tokens + input_tokens) > self.max_input_tokens
        ):
            return f"Request may exceed estimated input token limit (Current: {self.total_input_tokens}, Needed: {input_tokens}, Max: {self.max_input_tokens})"
        return "Token limit potentially exceeded (relying on API check)"

    @staticmethod
    def _convert_openai_to_gemini_message(message: Union[dict, Message]) -> Optional[Dict[str, Any]]:
        """Converts a single OpenAI-like message to Gemini's dictionary format."""
        if isinstance(message, Message):
            msg_dict = message.to_dict()
        elif isinstance(message, dict):
            msg_dict = message
        else:
            logger.warning(f"Unsupported message type for conversion: {type(message)}")
            return None

        role = msg_dict.get("role")
        content = msg_dict.get("content")
        # tool_calls = msg_dict.get("tool_calls") # Received from model, not sent
        tool_call_id = msg_dict.get("tool_call_id") # Used in tool response message
        name = msg_dict.get("name") # Function name for tool response message

        gemini_role = ROLE_MAP.get(role)
        if not gemini_role:
            if role == 'system':
                 # Handle system message - map to user or handle separately in format_messages
                 gemini_role = 'user' # Default mapping if system role not directly supported
                 logger.debug("Mapping system role to user for history construction.")
            else:
                 logger.warning(f"Unsupported role 	'{role}'	, skipping message.")
                 return None

        parts: List[Union[str, Dict[str, Any]]] = []

        # Handle content (text and images)
        if content:
            if isinstance(content, str):
                parts.append(content) # Simple text
            elif isinstance(content, list):
                # Handle list content (likely multimodal from OpenAI format)
                for item in content:
                    if isinstance(item, str):
                         parts.append(item)
                    elif isinstance(item, dict):
                        if item.get("type") == "text":
                            parts.append(item.get("text", ""))
                        elif item.get("type") == "image_url":
                            image_data = item.get("image_url", {})
                            url = image_data.get("url")
                            if url and url.startswith("data:image"): # Base64 data URI
                                try:
                                    # Extract mime type and base64 data for Gemini inline_data format
                                    header, base64_data = url.split(',', 1)
                                    mime_type = header.split(';')[0].split(':')[1]
                                    parts.append({"inline_data": {"mime_type": mime_type, "data": base64_data}})
                                except Exception as e:
                                    logger.warning(f"Could not parse image data URI: {e}, skipping image.")
                            elif url:
                                 # Downloading remote URLs is not implemented here
                                 logger.warning(f"Image URLs need download/conversion. Skipping image: {url}")
            else:
                 logger.warning(f"Unsupported content type: {type(content)}, skipping content.")

        # Handle tool responses (messages with role 'tool')
        if role == "tool" and tool_call_id and name and content:
             gemini_role = 'function' # Gemini expects 'function' role for tool responses
             # Gemini expects function_response part with name and response content
             response_part_content = content
             try:
                 # Gemini expects response content as a dict. Try parsing if it's JSON.
                 parsed_content = json.loads(content)
                 response_part_content = parsed_content
             except (json.JSONDecodeError, TypeError):
                 # If not JSON, wrap the raw content in a dict (common pattern)
                 response_part_content = {"content": content}

             parts.append({
                 "function_response": {
                     "name": name, # The name of the function that was called
                     "response": response_part_content
                 }
             })

        # Skip messages that end up with no parts (unless it's a model placeholder? Unlikely needed)
        if not parts:
             # logger.debug(f"Skipping message with no parts: Role={role}")
             return None

        return {"role": gemini_role, "parts": parts}

    @staticmethod
    def format_messages(
        messages: List[Union[dict, Message]],
        system_instruction: Optional[str] = None
    ) -> Tuple[List[Dict[str, Any]], Optional[Dict[str, Any]]]:
        """Formats messages for Gemini API, handling system prompt and merging roles."""
        gemini_messages: List[Dict[str, Any]] = []
        gemini_system_instruction: Optional[Dict[str, Any]] = None
        processed_system_message = False

        # Handle explicit system instruction first
        if system_instruction:
            # Use the dedicated system instruction field if the model supports it
            # Otherwise, it needs to be merged into the first user message (handled below)
            # For simplicity, we'll create the dict here and let the API call decide
            gemini_system_instruction = {"role": "system", "parts": [system_instruction]}
            processed_system_message = True
            logger.info("Using provided system instruction.")

        # Process conversation messages
        potential_system_content = []
        for message in messages:
            msg_dict = message.to_dict() if isinstance(message, Message) else message
            role = msg_dict.get("role")

            # Collect system messages from history if no explicit one was given
            if role == "system":
                if not processed_system_message:
                     sys_content = msg_dict.get("content", "")
                     if sys_content:
                         potential_system_content.append(sys_content)
                else:
                    logger.warning("Explicit system instruction provided, ignoring system message found in history.")
                continue # Don't add system messages directly to history yet

            # Convert other messages (user, assistant, tool/function)
            converted_msg = LLM._convert_openai_to_gemini_message(message)
            if converted_msg:
                gemini_messages.append(converted_msg)

        # Handle collected system messages if no explicit instruction was set
        if potential_system_content and not gemini_system_instruction:
            full_system_content = "\n".join(potential_system_content)
            gemini_system_instruction = {"role": "system", "parts": [full_system_content]}
            logger.info("Using system message(s) found in history as system instruction.")

        # Merge consecutive messages of the same role (user/model/function)
        merged_messages: List[Dict[str, Any]] = []
        if gemini_messages:
            # Start with the first message
            current_message = gemini_messages[0].copy()
            current_message['parts'] = list(current_message.get('parts', []))

            for next_msg in gemini_messages[1:]:
                # Make a copy to avoid modifying the original list during iteration
                next_msg_copy = next_msg.copy()
                next_msg_copy['parts'] = list(next_msg_copy.get('parts', []))

                # Merge if roles are the same AND the role is mergeable ('user' or 'model')
                # Don't merge consecutive 'function' responses.
                if next_msg_copy['role'] == current_message['role'] and current_message['role'] in ['user', 'model']:
                    current_message['parts'].extend(next_msg_copy['parts'])
                else:
                    # Role changed or is 'function', add the completed message and start new one
                    merged_messages.append(current_message)
                    current_message = next_msg_copy
            
            # Add the last message being processed
            merged_messages.append(current_message)

        # Gemini API constraints check (simplified):
        # - Roles should ideally alternate user/model.
        # - Function role follows model role.
        # This implementation relies on the input being mostly correct.
        # It merges consecutive user/model messages but doesn't reorder.
        # If the first message isn't 'user', and no system instruction is used,
        # the API might raise an error depending on the model.

        # If a system instruction was derived but the model might not support it,
        # prepend it to the first user message (if one exists).
        # This logic depends on knowing which models support the system role.
        # For now, we pass gemini_system_instruction and let the API handle it.

        return merged_messages, gemini_system_instruction

    async def _call_gemini_api(
        self,
        contents: List[Dict[str, Any]],
        generation_config: Dict[str, Any],
        stream: bool,
        tools: Optional[List[Any]] = None, # Expects list of genai.Tool objects
        tool_config: Optional[Dict[str, Any]] = None,
        system_instruction: Optional[Dict[str, Any]] = None
    ) -> GenerateContentResponse:
        """Internal helper to make the API call with error handling."""
        try:
            logger.debug(f"Sending request to Gemini. Contents: {json.dumps(contents, indent=2)}, System: {system_instruction}, Tools: {tools}, ToolConfig: {tool_config}, Config: {generation_config}, Stream: {stream}")
            
            api_args = {
                "contents": contents,
                "generation_config": generation_config,
                "stream": stream,
            }
            if tools:
                api_args["tools"] = tools
            if tool_config:
                api_args["tool_config"] = tool_config
            
            # Pass system_instruction if available - library/model handles compatibility
            # Note: Some older models might error if this is passed.
            # Consider adding a check based on self.model_name if needed.
            # if system_instruction and IS_SYSTEM_INSTRUCTION_SUPPORTED(self.model_name):
            #    api_args["system_instruction"] = system_instruction
            # Or, if not supported, merge system_instruction into the first user message parts
            # This merging logic would ideally be in format_messages

            response = await self.client.generate_content_async(**api_args)
            return response
        except google_exceptions.InvalidArgument as e:
            logger.error(f"Gemini API Invalid Argument: {e}. Request details logged above.")
            # Often indicates malformed input (e.g., role issues, bad parts)
            raise ValueError(f"Gemini request failed (Invalid Argument): {e}") from e
        except google_exceptions.FailedPrecondition as e:
             logger.error(f"Gemini API Failed Precondition: {e}. Check API key and billing status.")
             raise ConnectionError(f"Gemini request failed (Failed Precondition): {e}") from e
        except google_exceptions.ResourceExhausted as e:
             logger.error(f"Gemini API Resource Exhausted (Rate Limit/Quota?): {e}")
             # Re-raise specific type for potential retry logic upstream
             raise google_exceptions.ResourceExhausted(f"Gemini request failed (Resource Exhausted): {e}") from e
        except google_exceptions.PermissionDenied as e:
             logger.error(f"Gemini API Permission Denied: {e}. Check API key permissions.")
             raise PermissionError(f"Gemini request failed (Permission Denied): {e}") from e
        except google_exceptions.GoogleAPIError as e:
             # Catch other specific Google API errors
             logger.error(f"Gemini API Error: {e}")
             raise # Re-raise the specific GoogleAPIError
        except Exception as e:
            # Catch any other unexpected errors
            logger.exception(f"Unexpected error calling Gemini API: {e}")
            raise # Re-raise the original exception

    async def ask(
        self,
        messages: List[Union[dict, Message]],
        system_msgs: Optional[List[Union[dict, Message]]] = None,
        stream: bool = False,
        temperature: Optional[float] = None,
    ) -> str:
        """Send a prompt to the Gemini LLM and get the text response."""
        system_instruction_str = None
        if system_msgs:
            # Combine multiple system messages into one string
            system_instruction_str = "\n".join([msg.get("content", "") if isinstance(msg, dict) else msg.content for msg in system_msgs if (msg.get("content", "") if isinstance(msg, dict) else msg.content)])
        
        history, system_instruction_obj = self.format_messages(messages, system_instruction_str)

        generation_config: Dict[str, Any] = {
            "temperature": temperature if temperature is not None else self.temperature,
            "max_output_tokens": self.max_output_tokens,
            # "candidate_count": 1, # Default is 1
        }
        if self.top_p is not None:
            generation_config["top_p"] = self.top_p
        if self.top_k is not None:
            generation_config["top_k"] = self.top_k

        response = await self._call_gemini_api(
            contents=history,
            generation_config=generation_config,
            stream=stream,
            system_instruction=system_instruction_obj
        )

        full_response_text = ""
        output_tokens = 0
        input_tokens = 0
        usage_metadata = None

        if stream:
            async for chunk in response:
                try:
                    # Append text from chunk
                    chunk_text = chunk.text
                    print(chunk_text, end="", flush=True)
                    full_response_text += chunk_text
                    # Store usage metadata if available (usually on the last chunk)
                    if hasattr(chunk, 'usage_metadata') and chunk.usage_metadata:
                         usage_metadata = chunk.usage_metadata
                except ValueError:
                    # Handle potential errors like blocked content during streaming
                    logger.warning(f"Could not decode stream chunk: {chunk}. Safety settings? Prompt Feedback: {getattr(chunk, 'prompt_feedback', 'N/A')}")
                except Exception as e:
                    logger.error(f"Error processing stream chunk: {e}")
            print() # Newline after streaming
        else:
            # Handle non-streaming response
            try:
                # Access text safely using response.text
                full_response_text = response.text
                # Get usage metadata if available
                usage_metadata = getattr(response, 'usage_metadata', None)
            except ValueError:
                 # Handle case where response is blocked (often raises ValueError on .text access)
                 logger.warning(f"ValueError accessing response text. Likely blocked content. Full response object: {response}")
                 # Log details if available
                 if response.prompt_feedback: logger.warning(f"Prompt Feedback: {response.prompt_feedback}")
                 if response.candidates:
                     for candidate in response.candidates:
                         logger.warning(f"Candidate Finish Reason: {getattr(candidate, 'finish_reason', 'N/A')}")
                         logger.warning(f"Candidate Safety Ratings: {getattr(candidate, 'safety_ratings', 'N/A')}")
                 full_response_text = "" # Return empty string for blocked content
            except Exception as e:
                logger.error(f"Unexpected error accessing non-streaming response text: {e}. Response: {response}")
                full_response_text = ""

        # Update token counts using usage metadata if found
        if usage_metadata:
             input_tokens = getattr(usage_metadata, 'prompt_token_count', 0)
             output_tokens = getattr(usage_metadata, 'candidates_token_count', 0)
             self.update_token_count(input_tokens, output_tokens)
        else:
             # Estimate tokens if metadata is missing (less accurate)
             logger.warning("Usage metadata not found in response. Token counts will be estimated.")
             # input_tokens_est = await self.count_tokens(history) # Requires history to be available
             output_tokens_est = await self.count_tokens(full_response_text)
             # self.update_token_count(input_tokens_est, output_tokens_est)
             self.update_token_count(0, output_tokens_est) # Update output only if input estimation is complex

        if not full_response_text and not stream: # Only warn if non-streamed response is empty and not due to blocking
            if not (hasattr(response, 'candidates') and response.candidates and getattr(response.candidates[0], 'finish_reason', 0) != 1):
                 logger.warning("Received empty text response from Gemini, and not due to known blocking.")

        return full_response_text.strip()

    async def ask_with_images(
        self,
        messages: List[Union[dict, Message]],
        images: List[Union[str, dict]], # Expects base64 strings or data URIs
        system_msgs: Optional[List[Union[dict, Message]]] = None,
        stream: bool = False,
        temperature: Optional[float] = None,
    ) -> str:
        """Send a prompt with images to the Gemini LLM."""
        # Basic check for vision model name part
        if not any(model_part in self.model_name for model_part in VISION_MODELS):
            raise ValueError(f"Model {self.model_name} may not support images. Use a vision model like {VISION_MODELS}")

        system_instruction_str = None
        if system_msgs:
            system_instruction_str = "\n".join([msg.get("content", "") if isinstance(msg, dict) else msg.content for msg in system_msgs if (msg.get("content", "") if isinstance(msg, dict) else msg.content)])

        if not messages:
             raise ValueError("Cannot add images to an empty message list.")
        
        # Modify a copy to avoid altering the original message list
        messages_copy = [m.copy() if isinstance(m, dict) else m.model_copy(deep=True) for m in messages]
        last_message_index = -1
        # Find the last user message to add images to
        for i in range(len(messages_copy) - 1, -1, -1):
             msg = messages_copy[i]
             role = msg.get('role') if isinstance(msg, dict) else msg.role
             if role == 'user':
                  last_message_index = i
                  break
        
        if last_message_index == -1:
             raise ValueError("No user message found to attach images to.")

        last_message = messages_copy[last_message_index]
        if isinstance(last_message, Message):
             last_msg_dict = last_message.model_dump()
        else: # Already a dict
             last_msg_dict = last_message

        # Ensure content is a list
        current_content = last_msg_dict.get('content')
        if isinstance(current_content, str):
            last_msg_dict['content'] = [current_content]
        elif not isinstance(current_content, list):
            last_msg_dict['content'] = []
        # else: content is already a list

        # Add image parts to the content list
        for img_data in images:
            if isinstance(img_data, str) and img_data.startswith('data:image'):
                try:
                    header, base64_str = img_data.split(',', 1)
                    mime_type = header.split(';')[0].split(':')[1]
                    last_msg_dict['content'].append({"inline_data": {"mime_type": mime_type, "data": base64_str}})
                except Exception as e:
                    logger.warning(f"Failed to parse image data URI: {e}, skipping image.")
            elif isinstance(img_data, str): # Assume raw base64
                 logger.warning("Raw base64 string provided, assuming image/jpeg.")
                 last_msg_dict['content'].append({"inline_data": {"mime_type": "image/jpeg", "data": img_data}})
            elif isinstance(img_data, dict) and 'inline_data' in img_data:
                 last_msg_dict['content'].append(img_data)
            else:
                logger.warning(f"Unsupported image format: {type(img_data)}. Skipping image.")

        # Update the message in the copied list
        messages_copy[last_message_index] = last_msg_dict

        # Format messages and prepare API call parameters
        history, system_instruction_obj = self.format_messages(messages_copy, system_instruction_str)

        generation_config: Dict[str, Any] = {
            "temperature": temperature if temperature is not None else self.temperature,
            "max_output_tokens": self.max_output_tokens,
        }
        if self.top_p is not None: generation_config["top_p"] = self.top_p
        if self.top_k is not None: generation_config["top_k"] = self.top_k

        # Call API (reuse logic from ask method for response processing)
        response = await self._call_gemini_api(
            contents=history,
            generation_config=generation_config,
            stream=stream,
            system_instruction=system_instruction_obj
        )

        # Process response (same logic as ask method)
        full_response_text = ""
        output_tokens = 0
        input_tokens = 0
        usage_metadata = None
        if stream:
            async for chunk in response:
                try:
                    chunk_text = chunk.text
                    print(chunk_text, end="", flush=True)
                    full_response_text += chunk_text
                    if hasattr(chunk, 'usage_metadata') and chunk.usage_metadata:
                         usage_metadata = chunk.usage_metadata
                except ValueError:
                    logger.warning(f"Could not decode stream chunk: {chunk}. Safety? Feedback: {getattr(chunk, 'prompt_feedback', 'N/A')}")
                except Exception as e:
                    logger.error(f"Error processing stream chunk: {e}")
            print()
        else:
            try:
                full_response_text = response.text
                usage_metadata = getattr(response, 'usage_metadata', None)
            except ValueError:
                 logger.warning(f"ValueError accessing response text (image query). Likely blocked. Response: {response}")
                 if response.prompt_feedback: logger.warning(f"Prompt Feedback: {response.prompt_feedback}")
                 # ... (rest of safety logging) ...
                 full_response_text = ""
            except Exception as e:
                logger.error(f"Unexpected error accessing non-streaming response text (image query): {e}. Response: {response}")
                full_response_text = ""
        
        if usage_metadata:
             input_tokens = getattr(usage_metadata, 'prompt_token_count', 0)
             output_tokens = getattr(usage_metadata, 'candidates_token_count', 0)
             self.update_token_count(input_tokens, output_tokens)
        else:
             logger.warning("Usage metadata not found in image response. Estimating tokens.")
             output_tokens_est = await self.count_tokens(full_response_text)
             self.update_token_count(0, output_tokens_est)

        if not full_response_text and not stream:
             if not (hasattr(response, 'candidates') and response.candidates and getattr(response.candidates[0], 'finish_reason', 0) != 1):
                  logger.warning("Received empty text response from Gemini for image query.")

        return full_response_text.strip()

    async def ask_tool(
        self,
        messages: List[Union[dict, Message]],
        system_msgs: Optional[List[Union[dict, Message]]] = None,
        tools: Optional[List[Any]] = None, # Expects list of genai.Tool objects
        tool_choice: TOOL_CHOICE_TYPE = ToolChoice.AUTO,
        temperature: Optional[float] = None,
        **kwargs, # Catch unused args like timeout
    ) -> Optional[Message]: # Returns OpenAI-like Message object with tool_calls if needed
        """Ask Gemini LLM using functions/tools and return the response."""
        # Check if model likely supports function calling
        if not any(model_part in self.model_name for model_part in FUNCTION_CALLING_MODELS):
             logger.warning(f"Model {self.model_name} may not support function calling. Attempting anyway. Recommended: {FUNCTION_CALLING_MODELS}")

        system_instruction_str = None
        if system_msgs:
            system_instruction_str = "\n".join([msg.get("content", "") if isinstance(msg, dict) else msg.content for msg in system_msgs if (msg.get("content", "") if isinstance(msg, dict) else msg.content)])

        history, system_instruction_obj = self.format_messages(messages, system_instruction_str)

        # --- Tool and Tool Config Processing --- 
        gemini_tools = tools
        # Basic check: If tools are provided, they should be genai.Tool objects or compatible dicts.
        # The calling code (e.g., agent) is responsible for formatting tools correctly.
        if tools and not isinstance(tools, list):
             logger.error(f"Invalid format for tools: expected List, got {type(tools)}")
             gemini_tools = None # Don't pass invalid tools
        elif tools and len(tools) > 0 and not hasattr(tools[0], 'function_declarations'):
             # Rough check if it looks like genai.Tool vs OpenAI dict format
             if isinstance(tools[0], dict) and tools[0].get("type") == "function":
                  logger.error("ask_tool received OpenAI-style tools. Conversion to genai.Tool format must happen upstream.")
                  gemini_tools = None # Don't pass incompatible format
             # else: Assume it might be a compatible dict structure or genai.Tool object

        # Map tool_choice to Gemini's tool_config dictionary
        gemini_tool_config: Optional[Dict[str, Any]] = None
        mode: str = "AUTO" # Default mode
        allowed_function_names: Optional[List[str]] = None

        # Determine mode based on tool_choice
        if tool_choice == ToolChoice.NONE:
            mode = "NONE"
        elif tool_choice == ToolChoice.AUTO:
            mode = "AUTO"
        elif isinstance(tool_choice, dict) and tool_choice.get("type") == "function":
             # OpenAI format for specifying a single function
             func_name = tool_choice.get("function", {}).get("name")
             if func_name:
                  mode = "ANY" # Gemini uses ANY mode to force *a* function call
                  allowed_function_names = [func_name] # Specify the allowed name
             else:
                  logger.warning(f"Specific function tool_choice lacks name: {tool_choice}. Defaulting to AUTO.")
                  mode = "AUTO"
        # Add handling for Gemini's direct function name string if needed
        elif isinstance(tool_choice, str) and tool_choice != "auto" and tool_choice != "none":
             mode = "ANY"
             allowed_function_names = [tool_choice]
        else: # Default to AUTO for other cases
             mode = "AUTO"
        
        # Construct the tool_config dictionary based on the mode
        # Only include tool_config if mode is not AUTO or if tools are present
        if mode != "AUTO" or gemini_tools:
             func_calling_config: Dict[str, Any] = {"mode": mode}
             if allowed_function_names:
                  func_calling_config["allowed_function_names"] = allowed_function_names
             gemini_tool_config = {"function_calling_config": func_calling_config}
        # --- End Tool Processing --- 

        generation_config: Dict[str, Any] = {
            "temperature": temperature if temperature is not None else self.temperature,
            # "max_output_tokens": self.max_output_tokens, # Often not needed/used for tool calls
        }
        if self.top_p is not None: generation_config["top_p"] = self.top_p
        if self.top_k is not None: generation_config["top_k"] = self.top_k

        # Tool calls require non-streaming response
        response = await self._call_gemini_api(
            contents=history,
            generation_config=generation_config,
            stream=False,
            tools=gemini_tools,
            tool_config=gemini_tool_config,
            system_instruction=system_instruction_obj
        )

        # --- Process Response --- 
        # Initialize response structure (OpenAI-like Message)
        response_message = Message(role="assistant", content=None, tool_calls=None)
        text_content = None
        function_calls = [] # List to hold OpenAI-formatted tool calls
        input_tokens = 0
        output_tokens = 0
        usage_metadata = getattr(response, 'usage_metadata', None)

        try:
            # Update token counts if metadata available
            if usage_metadata:
                input_tokens = getattr(usage_metadata, 'prompt_token_count', 0)
                output_tokens = getattr(usage_metadata, 'total_token_count', 0) # Includes prompt+candidates
                # Adjust output tokens if needed: candidates_token_count might be more accurate for just output
                output_tokens = getattr(usage_metadata, 'candidates_token_count', output_tokens - input_tokens)
                self.update_token_count(input_tokens, output_tokens)

            # Check candidates for function calls or text parts
            if response.candidates:
                candidate = response.candidates[0] # Process first candidate
                finish_reason = getattr(candidate, 'finish_reason', None)
                safety_ratings = getattr(candidate, 'safety_ratings', [])

                # Log finish reason and safety ratings for debugging
                if finish_reason and finish_reason != 1: # 1 = STOP
                     logger.warning(f"Candidate finished with reason: {finish_reason}")
                if safety_ratings and any(rating.probability > 1 for rating in safety_ratings):
                     logger.warning(f"Candidate has safety concerns: {safety_ratings}")

                # Extract parts from candidate content
                if candidate.content and hasattr(candidate.content, 'parts'):
                    for part in candidate.content.parts:
                        # Check for function call
                        if hasattr(part, 'function_call') and part.function_call:
                            fc = part.function_call
                            # Convert Gemini FunctionCall to OpenAI-like dict format
                            tool_call_dict = {
                                "id": f"call_{os.urandom(8).hex()}", # Generate unique ID
                                "type": "function",
                                "function": {
                                    "name": fc.name,
                                    # Gemini args are dict, OpenAI expects JSON string
                                    "arguments": json.dumps(fc.args or {})
                                }
                            }
                            function_calls.append(tool_call_dict)
                        # Check for text part
                        elif hasattr(part, 'text') and part.text:
                            text_content = (text_content or "") + part.text
            
            # Populate the Message object based on extracted parts
            if function_calls:
                 response_message.tool_calls = function_calls
                 # Include text if the model provided both (uncommon but possible)
                 if text_content:
                      response_message.content = text_content.strip()
                 logger.info(f"Gemini returned function calls: {[fc['function']['name'] for fc in function_calls]}")
            elif text_content:
                 # Only text response
                 response_message.content = text_content.strip()
                 logger.info(f"Gemini returned text response: {text_content[:100]}...")
            else:
                 # No function calls and no text -> likely an issue or blocked response
                 logger.warning(f"Gemini returned no text or function calls. Finish Reason: {finish_reason}. Safety: {safety_ratings}. Prompt Feedback: {response.prompt_feedback}")
                 return None # Indicate no valid actionable response

            return response_message

        except Exception as e:
            # Catch errors during response processing
            logger.exception(f"Error processing Gemini tool response: {e}. Response object: {response}")
            raise # Re-raise the exception

